#include "esp01s_mqtt.h"
#include <string.h> // strlen, strstr
#include <stdio.h>  // sprintf
#include "stm32f10x.h"
#include "usart.h"
#include "led.h"
// --- ?????? ---
unsigned char wifi_connected_flag = 0; // 0=FALSE, 1=TRUE
unsigned char mqtt_connected_flag = 0; // 0=FALSE, 1=TRUE

// ?? AT ???????
// ???: 1 ??????, 0 ??????
/*unsigned char ESP8266_SendCmd(const char *cmd, const char *ack1, const char *ack2, u16 waittime)
{
    // ???? (C89)
    u16 wait_cnt;
    u16 current_recv_len;
    unsigned char result;
    char cmd_buffer[USART1_MAX_RECV_LEN]; // ?? USART1 ??????

    // ???
    wait_cnt = 0;
    result = 0; // ?????

    // ??? \r\n ???
    if ((strlen(cmd) + 2) >= sizeof(cmd_buffer)) {
        OLED_ShowStatus(6, "CMD Too Long!");
        delay_ms(1000); OLED_ShowStatus(6, "");
        return 0; // ????
    }
    sprintf(cmd_buffer, "%s\r\n", cmd);
LED0_ON(); delay_ms(1000); LED0_OFF();

    USART1_ClearBuffer(); // ?????
    USART1_SendString(cmd_buffer); // ????

    // ????
    while (wait_cnt < waittime)
    {
        if (USART1_IsFrameReceived()) // ?????????
        {
            current_recv_len = USART1_RX_STA & 0x7FFF;
            if (current_recv_len < USART1_MAX_RECV_LEN) {
                USART1_RX_BUF[current_recv_len] = '\0'; // ?? null ??
            } else {
                USART1_RX_BUF[USART1_MAX_RECV_LEN - 1] = '\0';
            }

            // ? OLED ??????????,????
            // OLED_ShowStatus(6, (char*)USART1_RX_BUF);
            // delay_ms(100);

            // ???????? ack1 ? ack2
            if ((ack1 != NULL && strstr((const char*)USART1_RX_BUF, ack1) != NULL) ||
                (ack2 != NULL && strstr((const char*)USART1_RX_BUF, ack2) != NULL))
            {
                result = 1; // ??
                USART1_ClearBuffer(); // ?????
                break; // ????
            }
            else
            {
                // ?????????,???????
                USART1_ClearBuffer();
            }
        }
        delay_ms(1);
        wait_cnt++;
    }

    // ??????,????????
    if (result == 0) {
        USART1_ClearBuffer();
    }

    return result; // ???????
}
*/

// ??? ESP8266 (?? Wi-Fi ? MQTT)
// ???: 1 ?????? MQTT ??, 0 ??
// ? esp01s_mqtt.c ?
unsigned char ESP8266_SendCmd(const char *cmd, const char *ack1, const char *ack2, u16 waittime)
{
    u16 wait_cnt = 0;
    unsigned char result = 0; // 0 for failure
    char cmd_buffer[USART1_MAX_RECV_LEN];

    sprintf(cmd_buffer, "%s\r\n", cmd);
    USART1_ClearBuffer();
    USART1_SendString(cmd_buffer);

    OLED_ShowStatus(6, "Waiting Rsp..."); // OLED ??????

    while (wait_cnt < waittime)
    {
        if (USART1_IsFrameReceived()) // ??????????? \n ????
        {
            OLED_ShowStatus(6, "Frame Recvd!"); // OLED ?????
            result = 1; // ???????
            // ?????????,???????,???????
            // USART1_ClearBuffer();
            break;
        }
        delay_ms(1);
        wait_cnt++;
    }

    if (result == 0) {
        OLED_ShowStatus(6, "Timeout!"); // OLED ????
    }
    delay_ms(1000); // ????????
    OLED_ShowStatus(6, ""); // ?????

    // ????????? ACK,??? result (??????????)
    // ??????,??????????? USART1_RX_BUF,
    // ??? main ????? (??????? printf)
    // ??? OLED,??????????
    // ??????,?????????,????? ACK ??
    if (result == 1) {
         // ???????????????? OLED (??????)
         // OLED_ShowString(0, 6, (const char*)USART1_RX_BUF, 8); // ???????????
         USART1_ClearBuffer(); // ??????
    }
    return result;
}
unsigned char ESP8266_Init(void)
{
    // ???? (C89)
    char cmd_buf[128];
    unsigned char cmd_result;

    OLED_ShowStatus(4, "ESP Init...");
    delay_ms(2000); // ?? ESP8266 ??

    // 1. AT Test
    cmd_result = ESP8266_SendCmd("AT", "OK", "ready", 1000);
    if (cmd_result == 0) { // ??
        OLED_ShowStatus(4, "AT Failed!");
        OLED_ShowStatus(6, "ERROR!");
        while(1); // ????,??
    }
    OLED_ShowStatus(4, "AT OK"); delay_ms(500); OLED_ShowStatus(4, "");

    // 2. Set Wi-Fi Mode to Station
    cmd_result = ESP8266_SendCmd("AT+CWMODE=1", "OK", "no change", 500);
    if (cmd_result == 0) { // ??
        OLED_ShowStatus(4, "Mode Failed!"); delay_ms(1000); OLED_ShowStatus(4, "");
    } else { // ??
        OLED_ShowStatus(4, "Mode OK"); delay_ms(500); OLED_ShowStatus(4, "");
    }

    // 3. Connect to AP
    sprintf(cmd_buf, "AT+CWJAP=\"%s\",\"%s\"", WIFI_SSID, WIFI_PASSWORD);
    OLED_ShowStatus(4, "Conn WiFi...");
    cmd_result = ESP8266_SendCmd(cmd_buf, "OK", "WIFI CONNECTED", 20000);
    if (cmd_result == 1) { // ??
        OLED_ShowStatus(4, "WiFi Connected"); wifi_connected_flag = 1; delay_ms(1000); OLED_ShowStatus(4, "");
    } else { // ??
        OLED_ShowStatus(4, "WiFi Conn Failed!"); wifi_connected_flag = 0; delay_ms(2000); OLED_ShowStatus(4, "");
    }

    // 4. Configure MQTT Client
    sprintf(cmd_buf, "AT+MQTTUSERCFG=0,1,\"%s\",\"%s\",\"%s\",0,0,\"%s\"", MQTT_CLIENT_ID, MQTT_USERNAME, MQTT_PASSWORD,KONG);
    OLED_ShowStatus(4, "Config MQTT...");
    cmd_result = ESP8266_SendCmd(cmd_buf, "OK", NULL, 500);
    if (cmd_result == 0) { // ??
        OLED_ShowStatus(4, "MQTT Cfg Failed!"); delay_ms(2000); OLED_ShowStatus(4, "");
    } else { // ??
        OLED_ShowStatus(4, "MQTT Cfg OK"); delay_ms(500); OLED_ShowStatus(4, "");
    }

    // 5. Connect to MQTT Broker (only if Wi-Fi is connected)
    mqtt_connected_flag = 0; // Assume failure
    if (wifi_connected_flag == 1) {
        sprintf(cmd_buf, "AT+MQTTCONN=0,\"%s\",%d,0", MQTT_BROKER_IP, MQTT_BROKER_PORT);
        OLED_ShowStatus(4, "Conn MQTT...");
        cmd_result = ESP8266_SendCmd(cmd_buf, "OK", "+MQTTCONNECTED", 5000);
        if (cmd_result == 1) { // ??
            OLED_ShowStatus(4, "MQTT Connected"); mqtt_connected_flag = 1; delay_ms(1000); OLED_ShowStatus(4, "");
        } else { // ??
            OLED_ShowStatus(4, "MQTT Conn Failed!"); mqtt_connected_flag = 0; delay_ms(2000); OLED_ShowStatus(4, "");
        }
    } else {
        OLED_ShowStatus(4, "Skip MQTT Conn"); delay_ms(2000); OLED_ShowStatus(4, "");
    }

    return mqtt_connected_flag; // Return final MQTT status
}

// ?? MQTT ??
// ???: 1 ????, 0 ????
unsigned char ESP8266_Publish(const char *topic, const char *data)
{
    // ???? (C89)
    char cmd_buf[USART1_MAX_RECV_LEN];
    u16 data_len;
    unsigned char result;
    unsigned char final_result;

    // ???
    data_len = strlen(data);
    result = 0; // Assume failure
    final_result = 0; // For final publish status

    if (ESP8266_IsMQTTConnected() == 0) {
        OLED_ShowStatus(6, "MQTT Disconnected"); delay_ms(500); OLED_ShowStatus(6, "");
        return 0; // Return failure
    }

    // 1. Send Publish command header
    sprintf(cmd_buf, "AT+MQTTPUB=0,\"%s\",\"%s\",0,0", topic, data);
    OLED_ShowStatus(6, "Pub Cmd...");

    // Send header and wait for ">"
    result = ESP8266_SendCmd(cmd_buf, ">", NULL, 500);

    if (result == 1) // If ">" received successfully
    {
        delay_ms(10); // Short delay

        // 2. Send payload data
        USART1_SendString(data); // Send data directly

        // 3. Wait for final "OK" or "+MQTTPUB:OK"
        // ?????(??? \r\n)??? ESP ????????? ACK
        final_result = ESP8266_SendCmd("", "OK", "+MQTTPUB:OK", 1500);

        if (final_result == 1) {
            OLED_ShowStatus(6, "Pub OK");
        } else {
            OLED_ShowStatus(6, "Pub Failed!");
        }
    }
    else // ">" not received
    {
        OLED_ShowStatus(6, "Pub Cmd Failed!");
        final_result = 0; // Ensure failure
    }

    delay_ms(500); OLED_ShowStatus(6, ""); // Clear status line
    return final_result; // Return final publish status
}


// ?? MQTT ????
// ???: 1 ???, 0 ???
unsigned char ESP8266_IsMQTTConnected(void)
{
    return mqtt_connected_flag;
}