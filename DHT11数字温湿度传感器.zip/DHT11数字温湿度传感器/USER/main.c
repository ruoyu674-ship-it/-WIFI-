#include "led.h"
#include "delay.h"
// #include "key.h" // ??????,?????
#include "sys.h"   // ????????
// ??? usart.h ??? (?? usart.h ??????? USART1 ??)
#include "dht11.h"
#include "oled_driver.h" // ???? OLED ?????
#include "usart.h"       // ?????? USART1 ????
#include "esp01s_mqtt.h" // ?? ESP8266 AT ?????
#include <stdio.h>   // ??? sprintf
#include <string.h>  // ??? strlen
#include "stm32f10x.h"

int main(void)
{
    // ???? (C89)
    u8 t = 0;
    u8 temperature;
    u8 humidity;
    char temp_str[5]; // ??????????
    char humi_str[5]; // ??????????
    unsigned char dht11_read_ok; // ???? DHT11 ???? (1=OK, 0=Error)

    // --- ??? ---
    delay_init();             // ???????
    NVIC_Configuration();     // ??NVIC???? (???????)
    LED_Init();               // LED?????
    OLED_Init();              // OLED??? (??????)
    delay_ms(100);
    OLED_Clear();
    OLED_ShowStatus(0, "System Init...");

    // DHT11 ???
    while(DHT11_Init() != 0) // 0 ????
    {
        OLED_ShowStatus(0, "DHT11 Error!"); delay_ms(1000);
    }
    OLED_ShowStatus(0, "DHT11 OK"); delay_ms(500);
     LED0_ON(); delay_ms(1000); LED0_OFF();
    // ??? USART1 (?? ESP8266)
    // !!! ?? ESP8266 ???? !!!
    uart_init(115200); // ?????? USART1 ?????
    OLED_ShowStatus(2, "USART1 OK"); delay_ms(500); OLED_ShowStatus(2, "");
    // ??? ESP8266 ?? (?? Wi-Fi, MQTT)
    ESP8266_Init(); // ??????? OLED ???????

    // ?????????????
    OLED_ShowStatus(0, ""); // ?? DHT11 OK
    OLED_ShowStatus(4, ""); // ?? ESP Init ?????

    // ? OLED ???????
    OLED_ShowString(0, 0, "Temp:", 16);
    OLED_ShowString(0, 2, "Humi:", 16);
    OLED_ShowString(80, 0, " C", 16);
    OLED_ShowString(80, 2, " %", 16);

    // --- ??? ---
    while(1) // ?? 1 ?? TRUE
    {
        if(t % 10 == 0) // ? 100ms ????
        {
            // ? 1 ????? DHT11 ??? MQTT
            if(t == 0)
            {
                 if (DHT11_Read_Data(&temperature, &humidity) == 0) { // 0 ????
                    dht11_read_ok = 1;
                } else {
                    dht11_read_ok = 0;
                }


                if(dht11_read_ok == 1) // ????
                {
                    // ? OLED ??????
                    OLED_ShowNum(60, 0, temperature, 2, 16);
                    OLED_ShowNum(60, 2, humidity, 2, 16);

                    // ???? MQTT (??????)
                    sprintf(temp_str, "%d", temperature);
                    ESP8266_Publish(MQTT_TEMP_TOPIC, temp_str); // Publish ????????? OLED ??

                    // ??????????
                    // delay_ms(100);

                    sprintf(humi_str, "%d", humidity);
                    ESP8266_Publish(MQTT_HUMI_TOPIC, humi_str);
                }
                else // ????
                {
                     OLED_ShowString(40, 0, "ERR", 16); // ????????
                     OLED_ShowString(40, 2, "ERR", 16);
                     OLED_ShowStatus(6, "DHT11 Read Failed!"); // ????????
                     delay_ms(1000);
                     OLED_ShowStatus(6, "");
                }
            }
        }

        delay_ms(10); // ?????
        t++;
        if(t >= 100) // ??????
        {
              if (GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_13)) // ???????? (????)
            {
                GPIO_ResetBits(GPIOC, GPIO_Pin_13); // ???? (??)
            }
            else // ???????? (????)
            {
                GPIO_SetBits(GPIOC, GPIO_Pin_13); // ???? (??)
            } // LED ????
        }
    } // end while(1)
} // end main 
