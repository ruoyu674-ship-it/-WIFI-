#include "oled_driver.h"
#include "delay.h"
#include <string.h> // ???? strlen ?
#include <stdio.h> // ???? sprintf ?
#include "oledfont.h"
// --- ???? I2C ???? (???????????) ---
#define OLED_SCLK_PORT    GPIOA
#define OLED_SCLK_PIN     GPIO_Pin_5
#define OLED_SDA_PORT     GPIOA
#define OLED_SDA_PIN      GPIO_Pin_7

// --- ????? GPIO ?? ---
#define OLED_SCLK_Clr()   GPIO_ResetBits(OLED_SCLK_PORT, OLED_SCLK_PIN)
#define OLED_SCLK_Set()   GPIO_SetBits(OLED_SCLK_PORT, OLED_SCLK_PIN)
#define OLED_SDA_Clr()    GPIO_ResetBits(OLED_SDA_PORT, OLED_SDA_PIN)
#define OLED_SDA_Set()    GPIO_SetBits(OLED_SDA_PORT, OLED_SDA_PIN)

// --- I2C ???? ---
// ??: IIC_Start(), IIC_Stop(), IIC_Wait_Ack(), Write_IIC_Byte()
// !!! ???? oled.c ?????????????? !!!
// ??:
static void IIC_Start(void)
{
    OLED_SCLK_Set();
    OLED_SDA_Set();
    delay_us(2); // ???
    OLED_SDA_Clr();
    delay_us(2);
    OLED_SCLK_Clr();
    delay_us(2);
}

static void IIC_Stop(void)
{
    OLED_SCLK_Clr();
    OLED_SDA_Clr();
    delay_us(2);
    OLED_SCLK_Set();
    delay_us(2);
    OLED_SDA_Set();
    delay_us(2);
}

// ??:Wait_Ack ???????????,?????????
static void IIC_Wait_Ack(void)
{
    // ?????? ACK,??????????? SDA ??
    // ????,??????
    OLED_SCLK_Set();
    delay_us(2);
    OLED_SCLK_Clr();
    delay_us(2);
}

static void Write_IIC_Byte(unsigned char IIC_Byte)
{
    // ???? (C89)
    unsigned char i;
    unsigned char m, da;

    da = IIC_Byte;
    OLED_SCLK_Clr(); // ????,????
    for (i = 0; i < 8; i++)
    {
        m = da;
        m = m & 0x80; // ????
        if (m == 0x80) {
            OLED_SDA_Set();
        } else {
            OLED_SDA_Clr();
        }
        da = da << 1; // ????
        delay_us(2);
        OLED_SCLK_Set(); // ????,?????
        delay_us(2);
        OLED_SCLK_Clr(); // ????,?????
    }
}

// --- OLED ??/?????? ---
#define OLED_CMD    0 // ???
#define OLED_DATA   1 // ???

static void OLED_WR_Byte(unsigned char dat, unsigned char cmd)
{
    IIC_Start();
    Write_IIC_Byte(0x78); // ????? (??? 0x78 ? 0x7A)
    IIC_Wait_Ack();
    if(cmd) { // ???
        Write_IIC_Byte(0x40);
    } else { // ???
        Write_IIC_Byte(0x00);
    }
    IIC_Wait_Ack();
    Write_IIC_Byte(dat);
    IIC_Wait_Ack();
    IIC_Stop();
}

// --- OLED ????? ---
void OLED_Init(void)
{
    // ???? (C89)
 	GPIO_InitTypeDef GPIO_InitStructure;

    // 1. ??? GPIO (PA5 SCL, PA7 SDA)
    // ?? GPIOA ??
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    // GPIO ??
	GPIO_InitStructure.GPIO_Pin = OLED_SCLK_PIN | OLED_SDA_PIN;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; // ???? (???? I2C)
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(OLED_SCLK_PORT, &GPIO_InitStructure); // SCL ? SDA ?? GPIOA
 	// ?????????
 	OLED_SCLK_Set();
 	OLED_SDA_Set();

    // 2. OLED ?????
    delay_ms(100); // ????

	OLED_WR_Byte(0xAE, OLED_CMD); // ????
	OLED_WR_Byte(0xD5, OLED_CMD); // ????????,????
	OLED_WR_Byte(0x80, OLED_CMD); // [3:0],????;[7:4],????
	OLED_WR_Byte(0xA8, OLED_CMD); // ??????
	OLED_WR_Byte(0x3F, OLED_CMD); // 1/64 duty (??)
	OLED_WR_Byte(0xD3, OLED_CMD); // ??????
	OLED_WR_Byte(0x00, OLED_CMD); // ??? 0

	OLED_WR_Byte(0x40, OLED_CMD); // ??????? [5:0],??

	OLED_WR_Byte(0x8D, OLED_CMD); // ?????
	OLED_WR_Byte(0x14, OLED_CMD); // bit2,??/??
	OLED_WR_Byte(0x20, OLED_CMD); // ????????
	OLED_WR_Byte(0x02, OLED_CMD); // [1:0],00,?????;01,?????;10,?????;??10;

	OLED_WR_Byte(0xA1, OLED_CMD); // ??????,bit0:0,0->0;1,0->127;
	OLED_WR_Byte(0xC8, OLED_CMD); // ?? COM ????;bit3:0,????;1,????? COM[N-1]->COM0;N:????
	OLED_WR_Byte(0xDA, OLED_CMD); // ?? COM ??????
	OLED_WR_Byte(0x12, OLED_CMD); // [5:4]??

	OLED_WR_Byte(0x81, OLED_CMD); // ?????
	OLED_WR_Byte(0xEF, OLED_CMD); // 1~255;??0x7F (????,????)

	OLED_WR_Byte(0xD9, OLED_CMD); // ???????
	OLED_WR_Byte(0xf1, OLED_CMD); // [3:0],PHASE 1;[7:4],PHASE 2;

	OLED_WR_Byte(0xDB, OLED_CMD); // ?? VCOMH ????
	OLED_WR_Byte(0x30, OLED_CMD); // [6:4] 000,0.65*vcc;001,0.77*vcc;011,0.83*vcc;

	OLED_WR_Byte(0xA4, OLED_CMD); // ??????;bit0:1,??;0,??;(??/??)
	OLED_WR_Byte(0xA6, OLED_CMD); // ??????;bit0:1,????;0,????

	OLED_WR_Byte(0xAF, OLED_CMD); // ????

	OLED_Clear(); // ??????
}

// --- OLED ???? ---
void OLED_Clear(void)
{
    // ???? (C89)
	u8 i,n;
	for(i=0; i<8; i++) // OLED ??? 8 ?
	{
		OLED_WR_Byte (0xb0+i, OLED_CMD);    //?????(0~7)
		OLED_WR_Byte (0x00, OLED_CMD);      //??????�????
		OLED_WR_Byte (0x10, OLED_CMD);      //??????�????
		for(n=0; n<128; n++) // ??? 128 ?
        {
            OLED_WR_Byte(0x00, OLED_DATA); // ?? 0 ??
        }
	}
}

// --- OLED ?????? ---
// x: ????? 0~127
// y: ????? 0~7
// chr: ??????
// Char_Size: ???? 16 (8x16) ? 12 (6x8) ??? (?? oledfont.h ??)
void OLED_ShowChar(u8 x, u8 y, u8 chr, u8 Char_Size)
{
    // ???? (C89)
	unsigned char c=0,i=0;
    unsigned char x_pos, y_page;

    c = chr - ' '; // ?????????
    x_pos = x;
    y_page = y;

    // ????????
    if(x_pos > OLED_X_MAX - 1) { x_pos = 0; y_page = y_page + (Char_Size / 8); } // ??
    if(y_page > (OLED_Y_MAX / 8) - 1) { y_page = 0; } // ?????

    if(Char_Size == 16) // 8x16 ??
    {
        // ???????????
        OLED_WR_Byte(0xB0 + y_page, OLED_CMD);
        OLED_WR_Byte(((x_pos & 0xF0) >> 4) | 0x10, OLED_CMD); // ????
        OLED_WR_Byte((x_pos & 0x0F), OLED_CMD); // ????
        // ?????? 8 ???
        for(i = 0; i < 8; i++) {
            OLED_WR_Byte(F8X16[c * 16 + i], OLED_DATA);
        }
        // ???????????
        OLED_WR_Byte(0xB0 + y_page + 1, OLED_CMD);
        OLED_WR_Byte(((x_pos & 0xF0) >> 4) | 0x10, OLED_CMD); // ????
        OLED_WR_Byte((x_pos & 0x0F), OLED_CMD); // ????
        // ?????? 8 ???
        for(i = 0; i < 8; i++) {
            OLED_WR_Byte(F8X16[c * 16 + i + 8], OLED_DATA);
        }
    }
    else if (Char_Size == 8 || Char_Size == 6 || Char_Size == 12) // 6x8 ? 8x8 (?? 6x8 ???)
    {
         // ?????????
        OLED_WR_Byte(0xB0 + y_page, OLED_CMD);
        OLED_WR_Byte(((x_pos & 0xF0) >> 4) | 0x10, OLED_CMD); // ????
        OLED_WR_Byte((x_pos & 0x0F), OLED_CMD); // ????
        // ?? 6 ???
        for(i = 0; i < 6; i++) {
             OLED_WR_Byte(F6x8[c][i], OLED_DATA); // ?? F6x8 ???
        }
    }
    // ?????????????????
}

// --- OLED ??????? ---
void OLED_ShowString(u8 x, u8 y, const char *p, u8 Char_Size)
{
    // ???? (C89)
    u8 x_pos, y_page;
    u8 char_width;

    x_pos = x;
    y_page = y;

    if(Char_Size == 16) {
        char_width = 8;
    } else if (Char_Size == 8 || Char_Size == 6 || Char_Size == 12) {
        char_width = 6;
    } else {
        char_width = 8; // ??? 8 ???
    }


    while (*p != '\0')
    {
        // ????????
        if (x_pos > (OLED_X_MAX - char_width))
        {
            x_pos = 0;
            y_page = y_page + (Char_Size / 8); // ?????(?????)
            if (y_page > (OLED_Y_MAX / 8) - (Char_Size / 8)) // ?????????
            {
                y_page = 0; // ?????
                OLED_Clear(); // ??:?????????
            }
        }
        OLED_ShowChar(x_pos, y_page, *p, Char_Size);
        x_pos += char_width;
        p++;
    }
}

// --- OLED ?????? ---
// m^n ?? (??????)
static u32 oled_pow(u8 m, u8 n)
{
    // ???? (C89)
	u32 result = 1;
	while(n--) result *= m;
	return result;
}

void OLED_ShowNum(u8 x, u8 y, u32 num, u8 len, u8 size2)
{
    // ???? (C89)
	u8 t,temp;
	u8 enshow=0;
    u8 char_width;

    if(size2 == 16) {
        char_width = 8;
    } else if (size2 == 8 || size2 == 6 || size2 == 12) {
        char_width = 6;
    } else {
        char_width = 8; // ??
    }

	for(t=0; t<len; t++)
	{
		temp = (num / oled_pow(10, len - t - 1)) % 10;
		if(enshow == 0 && t < (len - 1))
		{
			if(temp == 0)
			{
				OLED_ShowChar(x + (char_width / 2) * t, y, ' ', size2); // ???????,???????????
				continue;
			} else {
                enshow = 1;
            }
		}
	 	OLED_ShowChar(x + (char_width / 2) * t, y, temp + '0', size2);
	}
}

// --- OLED ???????? ---
// y_page: 0, 2, 4, 6 (??16?????)
void OLED_ShowStatus(u8 y_page, const char *status_msg)
{
    // ???? (C89)
    u8 i;
    u8 start_page;

    // ?????
    start_page = (y_page / 2) * 2; // ????????

    // ????????
    if (start_page >= (OLED_Y_MAX / 8)) return;

    // ?????????
    OLED_WR_Byte(0xB0 + start_page, OLED_CMD);
    OLED_WR_Byte(0x00, OLED_CMD); // ????
    OLED_WR_Byte(0x10, OLED_CMD); // ????
    for(i = 0; i < 128; i++) OLED_WR_Byte(0, OLED_DATA);

    if ((start_page + 1) < (OLED_Y_MAX / 8)) // ???????
    {
        OLED_WR_Byte(0xB0 + start_page + 1, OLED_CMD);
        OLED_WR_Byte(0x00, OLED_CMD); // ????
        OLED_WR_Byte(0x10, OLED_CMD); // ????
        for(i = 0; i < 128; i++) OLED_WR_Byte(0, OLED_DATA);
    }

    // ?????????????? (?? 16 ????)
    OLED_ShowString(0, start_page, status_msg, 16);
}

// ... ?? OLED ???? (????????) ...